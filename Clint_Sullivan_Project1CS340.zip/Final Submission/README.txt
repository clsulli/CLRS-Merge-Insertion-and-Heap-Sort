TO RUN PROGRAM:

1.  Store project directory on home cs server somewhere.
2.  CD into project directory.
3.  Do command "ls" and make sure you see "main.py" along with another directory called "Wordlists"
4.  After verifying you are in correct directory, do command "python main.py"
5.  Follow program prompts until completion.
6.  Done.